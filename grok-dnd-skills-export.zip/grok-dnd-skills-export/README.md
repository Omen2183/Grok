# Grok D&D Skills Suite — Full Documentation

**Exported: June 24, 2026**  
**For user: Omen2183 (Josh)**

This repository contains the complete specifications and documentation for the full suite of D&D skills available through Grok. These skills form a powerful, interconnected system for running persistent, high-quality 5e (and heavy homebrew) campaigns — both classic tabletop and kingdom/domain-builder style.

## Overview

The D&D skills ecosystem is designed around a central orchestrator (`dnd-persistent-dm`) that intelligently routes requests to specialized skills. Everything is stateful, campaign-aware, and built for long-running games with minimal manual bookkeeping.

**Core Philosophy**
- Persistent state across sessions and campaigns
- Heavy homebrew support
- Clean separation between narration, mechanics, and world memory
- Mobile-friendly output by default
- Python backends for reliability and transparency (dice rolls, combat tracking, loot ledgers, etc.)

## Skills Included

| Skill                        | Purpose                                                                 | Key Triggers                          |
|------------------------------|-------------------------------------------------------------------------|---------------------------------------|
| dnd-persistent-dm           | Central DM orchestrator for playing/continuing campaigns               | "Let's play D&D", "DM mode", "Continue the campaign" |
| dnd-character-manager       | Player character sheets, leveling, inventory, attunement, death saves  | Level up, update sheet, manage inventory |
| dnd-combat-assistant        | Initiative, HP, conditions, turn tracking (mobile-optimized)           | Start combat, next turn, damage, add condition |
| dnd-content-forge           | Balanced encounters, NPCs, magic items, quests, kingdom projects       | Generate encounter, create NPC, loot, kingdom ideas |
| dnd-dice-engine             | Accurate 5e dice rolling with advantage, keep highest, homebrew        | Any roll request                      |
| dnd-loot-generator          | Flavorful magic items & hoards with "already found" ledger             | Generate loot, what's in the chest?   |
| dnd-lore-archivist          | Deep campaign lore, NPC knowledge, faction relationships               | What does [NPC] know?, update lore    |
| dnd-npc-personality-weaver  | Rich, memorable NPCs with personality, secrets, speech patterns        | Generate NPC, make this character interesting |
| dnd-rules-reference         | Accurate 5e rules clarification and edge cases                         | Rules questions, condition rulings    |
| dnd-rumor-event-generator   | Rumors, faction actions, random world events                           | What's happening in the world?        |
| dnd-session-scribe          | Session recaps, XP tracking, state synchronization                     | End of session, recap                 |
| dnd-utils                   | Shared state management, audits, helpers                               | Internal / advanced use               |
| dnd-visual-weaver           | Consistent visual prompts for characters, locations, scenes            | Show me / generate art for...         |
| dnd-voice-assistant         | Voice-optimized layer for full campaigns                               | Voice mode D&D                        |

## How the Skills Work Together

- **dnd-persistent-dm** is the brain. It initializes campaigns, maintains world state, and delegates to other skills.
- **State lives in** `/home/workdir/artifacts/dnd-campaigns/[Campaign Name]/` (state/, npcs/, logs/, combat/, etc.)
- **Python backends** in each skill's `scripts/` folder provide reliable, auditable logic (dice_roller.py, combat_tracker.py, etc.).
- **Cross-skill sync** happens automatically for HP, conditions, inventory, lore, and session history.
- **Kingdom / Domain mode** is fully supported alongside classic tabletop play.

## Using These Skills

These skills are designed to be used conversationally with Grok. You rarely need to call them by name — just speak naturally ("Start combat", "Level up my rogue", "What does the barkeep know about the missing caravan?").

For advanced control or scripting, you can invoke the Python tools directly from the terminal or other skills.

## Export Notes

This export contains the raw `SKILL.md` specification files for each skill. They describe:
- When to activate
- Core capabilities
- Integration patterns
- State handling
- Behavior guidelines
- Python backend details

They are excellent for reference, backup, or if you ever want to recreate / extend the system.

## Recommended Next Steps

1. Create a new GitHub repo (public or private).
2. Upload this entire folder (or drag the .md files in).
3. Optionally add a `.gitignore` and any campaign exports you want to version.

If you'd like me to:
- Generate a single combined Markdown file with everything
- Add more files (e.g., example campaign structure, loot guidelines, encounter budgets)
- Help you set up the repo manually with copy-paste content
- Export your actual campaign states as well

Just let me know — happy to refine this export further!

---

*Generated with care by Ara for your D&D adventures. May your rolls be high and your campaigns legendary.*